using Microsoft.AspNetCore.Mvc;

namespace LoanRatesAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RatesController : ControllerBase
    {
        // This endpoint returns mock loan rate data based on loanType and term
        [HttpGet]
        public IActionResult GetRates([FromQuery] string loanType, [FromQuery] int term)
        {
            var rate = new {
                loanType = loanType,
                term = term,
                interestRate = 5.85,
                description = "Mock rate data for testing"
            };
            return Ok(rate);
        }
    }
}
