## Endpoint
`GET /api/rates?loanType=owner-occupied&term=30`

## Sample Response
{
  "loanType": "owner-occupied",
  "term": 30,
  "interestRate": 5.85,
  "description": "Mock rate data for testing"
}

## How to Run

Visit: `https://localhost:5001/api/rates?loanType=owner-occupied&term=30`
